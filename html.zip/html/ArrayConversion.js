var InputArray = [[1,2,3,4],[10,20,30,40]];
var OutputArray = [];

function transpose(InputArray) {
  var arraywidth = InputArray.length || 0;
  var arrayheight = InputArray[0] instanceof Array ? InputArray[0].length : 0;
  if(arrayheight === 0 || arraywidth === 0) { return []; }
	var i, j;
	  for(i=0; i<arrayheight; i++) {
		OutputArray[i] = [];
		for(j=0; j<arraywidth; j++) {
		  OutputArray[i][j] = InputArray[j][i];
		}
	  }
  return OutputArray;
}

console.log(InputArray);
transpose(InputArray);
console.log(OutputArray);

