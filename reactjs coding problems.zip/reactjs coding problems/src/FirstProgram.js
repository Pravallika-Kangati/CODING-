import React from "react";
//import "bootstrap/dist/css/bootstrap.min.css";
import "./styles.css";

class FirstProgram extends React.Component {
  constructor() {
    super();
    this.state = { count: 0 };
    //   this.ParagraphClicked = this.ParagraphClicked.bind(this);
  }
  ParagraphClicked = event => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    return (
      <div className="ClickParagraph">
        <h2> Count of Click On a Paragraph Element : {this.state.count}</h2>
        <p onClick={this.ParagraphClicked}>Click on a Paragraph Element</p>
      </div>
    );
  }
}

export default FirstProgram;
