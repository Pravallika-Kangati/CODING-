import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles.css";

class StopWatch extends React.Component {
  constructor() {
    super();
    this.state = { seconds: 0 };
  }

  startTimer = e => {
    this.incrementer = setInterval(() => {
      this.setState({
        seconds: this.state.seconds + 1
      });
    }, 1000);
    this.setState({ incrementer: this.incrementer });
  };

  stopTimer = e => {
    clearInterval(this.state.incrementer);
    this.setState({
      lastClearedIncrementer: this.incrementer
    });
  };

  render() {
    return (
      <div className="StopWatch">
        <h1 style={{ color: "blue", fontFamily: "verdana" }}>Stop Watch</h1>
        <h2>{this.state.seconds} secs</h2>
        <button
          type="button"
          className="btn btn-success"
          onClick={this.startTimer}
        >
          Start
        </button>
        &nbsp;&nbsp;&nbsp;
        <button
          type="button"
          className="btn btn-danger"
          onClick={this.stopTimer}
        >
          Stop
        </button>
      </div>
    );
  }
}

export default StopWatch;
